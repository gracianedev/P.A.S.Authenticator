package com.pas.pasauthenticator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PasauthenticatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
